// ============================================================================
//
//  Project:  CuEyeDll Dynamic loading of uEye DLL
//
//  Module:    Dynamic_uEye_api.cpp
//
// ============================================================================

//////////////////////////////////////////////////////////////////////
#include "dynamic_ueye_api.h"

#ifdef __linux__
    #include <dlfcn.h>
#else
    #include <tchar.h>
#endif

CuEyeDll::CuEyeDll()
{
    m_hMod = NULL;
}

CuEyeDll::~CuEyeDll()
{
    Disconnect();
}

bool CuEyeDll::IsLoaded()
{
    return m_hMod != NULL;
}

bool CuEyeDll::_SetPointers(bool Load)
{
    int tried = 0;
    int made = 0;

#ifdef __linux__
    #define import_function dlsym
#else
    #define import_function GetProcAddress
#endif
#define UEYE_MACRO_DO(name)                                                         \
    tried++;                                                                        \
    if (!Load)                                                                      \
    {                                                                               \
        made++;                                                                     \
        is_##name = NULL;                                                           \
    }                                                                               \
    else                                                                            \
    {                                                                               \
        if ((is_##name = (IS__##name)import_function(m_hMod, "is_" #name)) != NULL) \
            made++;                                                                 \
    }
#define DECLARE(pars)

#include "ueye_api_macro.h"

#undef DECLARE
#undef UEYE_MACRO_DO
#undef import_function

    return tried == made;
}

long CuEyeDll::Connect(const IS_CHAR* dllname)
{
    long lRet = ICB_SUCCESS;

    if (dllname != NULL)
    {
#ifdef __linux__
        m_hMod = dlopen(dllname, RTLD_LAZY);
#else
        m_hMod = LoadLibrary(dllname);
#endif
        if (m_hMod != NULL)
        {
            if (!_SetPointers(true))
            {
                Disconnect();
                lRet = ICB_NO_SUCCESS;
            }
        }
        else
            lRet = ICB_NO_SUCCESS;
    }
    else
        lRet = ICB_NO_SUCCESS;

    return lRet;
}

long CuEyeDll::Disconnect()
{
    _SetPointers(false);
    if (m_hMod != NULL)
#ifdef __linux__
        dlclose(m_hMod);
#else
        FreeLibrary(m_hMod);
#endif
    m_hMod = NULL;
    return ICB_SUCCESS;
}
